package NoticeBBS;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UTIL.*;

public class BoardView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String url="boardview.jsp";
		int num=Integer.parseInt(request.getParameter("num"));
		
		NoticeDAO bao=NoticeDAO.getInstance();
		NoticeVO bvo;
		try {
			bvo = bao.getNoti(num);	
			request.setAttribute("bbs", bvo);
			RequestDispatcher dis=request.getRequestDispatcher(url);
			dis.forward(request, response);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
