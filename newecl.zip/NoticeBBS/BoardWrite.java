package NoticeBBS;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UTIL.*;

public class BoardWrite implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		NoticeVO bvo=new NoticeVO();
		
		bvo.setTitle(request.getParameter("title"));		
		bvo.setContent(request.getParameter("content"));
		bvo.setAdmin(request.getParameter("email"));
		NoticeDAO bao=NoticeDAO.getInstance();
		try {
			bao.insertNoti(bvo);
			//new BoardListAction().execute(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String url="boardview.jsp";
		
		
		bao=NoticeDAO.getInstance();
		
		try {
			Connection conn = null;
			PreparedStatement pre = null;
			ResultSet rs = null;
			conn = ConnectDB.getConnection();
			System.out.println("conn ok");
			String sql1 = "select * from totnotice order by notinum desc";
			pre = conn.prepareStatement(sql1);
			int newnum = 0;
			rs=pre.executeQuery();
			if(rs.next())
				newnum=rs.getInt(1);	
			
			bvo = bao.getNoti(newnum);
			request.setAttribute("bbs", bvo);
			RequestDispatcher dis=request.getRequestDispatcher(url);
			dis.forward(request, response);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
