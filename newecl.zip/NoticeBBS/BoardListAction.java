package NoticeBBS;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UTIL.*;

public class BoardListAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String url="NoticeList.jsp";
		NoticeDAO bbsAo=NoticeDAO.getInstance();
		
		try {
			ArrayList<NoticeVO> bbslist=bbsAo.listNoti();
			request.setAttribute("bbslist", bbslist);
			RequestDispatcher dis=request.getRequestDispatcher(url);
			dis.forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
