package NoticeBBS;

import java.sql.Timestamp;

public class NoticeVO {
		 
	 private int notinum;	 
	 private String admin;
	 private String title;
	 private String content;
	 private Timestamp indate;
	

	
	public int getNotinum() {
		return notinum;
	}
	public void setNotinum(int notinum) {
		this.notinum = notinum;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public Timestamp getIndate() {
		return indate;
	}
	public void setIndate(Timestamp indate) {
		this.indate = indate;
	}
	 
}
