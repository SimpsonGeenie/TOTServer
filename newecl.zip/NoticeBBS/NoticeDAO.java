package NoticeBBS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import MEMBER.MemberVO;
import QnABBS.QnaVO;
import UTIL.ConnectDB;

public class NoticeDAO {
	
	Connection conn = null;
	PreparedStatement pre = null;
	ResultSet rs = null;
	
	private NoticeDAO() {
	}

	private static NoticeDAO instance = new NoticeDAO();

	public static NoticeDAO getInstance() {
		return instance;
	}
	

	public ArrayList<NoticeVO> listNoti() {
		ArrayList<NoticeVO> qnaList = new ArrayList<NoticeVO>();
		String sql = "select * from totnotice order by notinum asc";

		
		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);			
			rs = pre.executeQuery();
			while (rs.next()) {
				NoticeVO nvo = new NoticeVO();
				nvo.setNotinum(rs.getInt("notinum"));
				nvo.setAdmin(rs.getString("admin"));
				nvo.setTitle(rs.getString("title"));
				nvo.setIndate(rs.getTimestamp("notidate"));
				qnaList.add(nvo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return qnaList;
	}

	public NoticeVO getNoti(int notinum) {
		NoticeVO nvo = null;
		String sql = "select * from totnotice where notinum=?";
		
		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);
			pre.setInt(1, notinum);
			rs = pre.executeQuery();
			if (rs.next()) {
				nvo = new NoticeVO();
				nvo.setNotinum(rs.getInt("notinum"));
				nvo.setAdmin(rs.getString("admin"));
				nvo.setTitle(rs.getString("title"));
				nvo.setContent(rs.getString("content"));
				nvo.setIndate(rs.getTimestamp("notidate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre);
		}
		return nvo;
	}
	

	public String insertNoti(NoticeVO nvo) {
		
		String okornot="notok";
		String sql = "insert into totnotice (title, " + 
	"content, admin, notidate) values(?, ?, ?, now())";
		
		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);
			pre.setString(1, nvo.getTitle());
			pre.setString(2, nvo.getContent());
			pre.setString(3, nvo.getAdmin());
			pre.executeUpdate();
			System.out.println(nvo.getTitle());
			okornot="ok";
		} catch (Exception e) {
			e.printStackTrace();
			okornot="notok";
		} finally {
			ConnectDB.close(conn, pre);
		}
		return okornot;
	}
			
	
		 public String fixNoti(QnaVO qnaVO) {
			 String sql = "update totnotice set title=?, content=? where notinum=?";
			 String okornot="notok";
			 try {
				 conn = ConnectDB.getConnection();
				 pre = conn.prepareStatement(sql);
				 System.out.println("start "+qnaVO.getTitle());
				 pre.setString(1, qnaVO.getTitle());
				 pre.setString(2, qnaVO.getContent());
				 pre.setInt(3, qnaVO.getQnanum());				 
				 pre.executeUpdate();
				 okornot="ok";
				 } catch (Exception e) {
				 e.printStackTrace();
				 okornot="notok";
				 } finally {
					 ConnectDB.close(conn, pre);
				 }
			 return okornot;
			 }
	
		 public String deleteQna(int qnanumber) {
			 String sql = "delete from totnotice where notinum=?";
			 String okornot="notok";
			 try {
				 conn = ConnectDB.getConnection();
				 pre = conn.prepareStatement(sql);
				 pre.setInt(1, qnanumber);
				 pre.executeUpdate();
				 System.out.println("delete compl");
				 okornot="ok";
				 } catch (Exception e) {
				 e.printStackTrace();
				 okornot="notok";
				 } finally {
					 ConnectDB.close(conn, pre);
				 }
			 return okornot;
		 }
}