package MEMBER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import UTIL.ConnectDB;

public class MemberDAO {
	scoreThread sThread=new scoreThread();
	Connection conn = null;
	PreparedStatement pre = null;
	ResultSet rs=null;
	
	private MemberDAO() {
	}

	private static MemberDAO instance = new MemberDAO();

	public static MemberDAO getInstance() {
		return instance;
	}

	public String confirmID(String trapperid) {
		
		String trapperidreturn=null;
		String usedornot=null;
		try {
			conn =ConnectDB.getConnection();
			pre = conn.prepareStatement(ConnectDB.SQLQuery(6));
			pre.setString(1, trapperid);
			rs = pre.executeQuery();
			if (rs.next()) {
				trapperidreturn=rs.getString("trapperid");
			}
			
			if(trapperidreturn==null){
				usedornot="unused";
			}else{
				usedornot="used";
			}
			System.out.println(trapperidreturn+" / "+usedornot);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre, rs);
		}
		return usedornot;
	}

	public int Login(String trapperid, String trapperpw) {
		int trapperaccount=0;
		MemberVO mvo = new MemberVO();
		String sql="select trapperaccount from totmember where trapperid=? and trapperpw=?";
		String sql1="UPDATE totmember SET lastlogin=now() WHERE trapperaccount=?;";
		
		try {
			
			conn =ConnectDB.getConnection();
			conn.setAutoCommit(false);
			conn.commit();
			pre = conn.prepareStatement(sql);
			pre.setString(1, trapperid);
			pre.setString(2, trapperpw);
			rs = pre.executeQuery();
			if (rs.next()) {
				mvo.setTrapperaccount(rs.getInt("trapperaccount"));
			}
			conn.commit();
			pre=conn.prepareStatement(sql1);
			pre.setInt(1, mvo.getTrapperaccount());
			pre.executeUpdate();
			System.out.println("login ok");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre, rs);
		}
		trapperaccount=mvo.getTrapperaccount();
		System.out.println(trapperaccount);
		return trapperaccount;
	}
	
	public MemberVO MyScoreAndTraps(int trapperaccount) {
		
		MemberVO mvo = new MemberVO();
		String sql="select score, howmanytraps from totmember where trapperaccount=?";
				
		try {
			sThread.start();
			conn =ConnectDB.getConnection();
			conn.setAutoCommit(false);
			conn.commit();
			pre = conn.prepareStatement(sql);
			pre.setInt(1, trapperaccount);
			rs = pre.executeQuery();
			if (rs.next()) {
				mvo.setScore(rs.getInt("score"));
				mvo.setHowmanytraps(rs.getInt("howmanytraps"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre, rs);
		}		
		
		return mvo;
	}
	
	

	public int insertMember(MemberVO mvo) {
		int myaccount = 0;
		String sql="insert into totmember("
				+ "trapperid, trapperpw, trappername, trappernickname, trapperphone"+
				 ",joindate ) values(?, ?, ?, ?, ?, now())";
		try {
			conn = ConnectDB.getConnection();
			conn.setAutoCommit(false);
			conn.commit();
			pre = conn.prepareStatement(sql);
			pre.setString(1, mvo.getTrapperid());
			pre.setString(2, mvo.getTrapperpw());
			pre.setString(3, mvo.getTrappername());
			pre.setString(4, mvo.getTrappernickname());
			pre.setString(5, mvo.getTrapperphone());
			pre.executeUpdate();
			conn.commit();
			myaccount=Login(mvo.getTrapperid(),mvo.getTrapperpw());
			System.out.println("show : "+myaccount);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre);
		}
		return myaccount;
	}
	public ArrayList<MemberVO> listMember(String member_name) {
		 ArrayList<MemberVO> memberList = new ArrayList<MemberVO>();
		
		 try {
		 conn = ConnectDB.getConnection();
		 pre = conn.prepareStatement(ConnectDB.SQLQuery(8));
		 if (member_name == "") {
			 pre.setString(1, "%");
		 } else {
			 pre.setString(1, member_name);
		 }
		 rs = pre.executeQuery();
		 while (rs.next()) {
		 MemberVO mvo = new MemberVO();
		 ConnectDB.MemberVOSetting(mvo, conn, pre, rs);
		 memberList.add(mvo);
		 }
		 } catch (Exception e) {
		 e.printStackTrace();
		 } finally {
			 ConnectDB.close(conn, pre, rs);
		 }
		 return memberList;
	}
	
	public int updateMember(MemberVO mvo) {
		int result = 0;
		String sql="update totmember set trapperpw=? where trapperaccount=?;";
		try {
			conn = ConnectDB.getConnection();
			 pre = conn.prepareStatement(sql);
			 pre.setString(1, mvo.getTrapperpw());
			 pre.setInt(2, mvo.getTrapperaccount());	
			result=pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre);
		}
		return result;
	}
	public int getOutMember(MemberVO mvo) {
		int result = 0;
		
		try {
			conn = ConnectDB.getConnection();
			 pre = conn.prepareStatement(ConnectDB.SQLQuery(10));	
			 pre.setString(1, mvo.getTrapperid());			
			result = pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre);
		}
		return result;
	}
	
	class scoreThread extends Thread {
       
        public void run() {
     while (true) {
    	 String sql1="update totmember set score = "
					+ "(select sum((now()-trapdate)/(3600*24)) from triportrap "
					+ "where triportrap.trapperaccount=totmember.trapperaccount);";
			String sql2="update totmember set howmanytraps = "
					+ "(select count(*)from triportrap where triportrap.trapperaccount"
					+ "=totmember.trapperaccount);";
			
			
			try {
				conn = ConnectDB.getConnection();
				 pre = conn.prepareStatement(sql1);
				 pre.executeUpdate();
				 System.out.println("ok?");
				 pre=null;
				 pre = conn.prepareStatement(sql2);
				 pre.executeUpdate();
				 System.out.println("ok?");
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ConnectDB.close(conn, pre);
			}

                try {
                    Thread.sleep(30000);
                } catch (InterruptedException e) {

                }
            }
        }
    }
	
	
	
	
}