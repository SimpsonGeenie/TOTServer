package MEMBER;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/jointot.do")
public class jointot extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public jointot() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();

		 MemberVO memberVO = new MemberVO();

		 memberVO.setTrapperid(request.getParameter("trapperid"));
		 memberVO.setTrapperpw(request.getParameter("trapperpw"));
		 memberVO.setTrappername(request.getParameter("trappername"));
		 memberVO.setTrappernickname(request.getParameter("trappernickname"));
		 memberVO.setTrapperphone(request.getParameter("trapperphone"));
		 
		 MemberDAO memberDAO = MemberDAO.getInstance();
		 memberDAO.insertMember(memberVO);
		
	}
}
