package MEMBER;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UTIL.Action;

public class JoinAction  implements Action {
	 @Override
	 public void execute(HttpServletRequest request, HttpServletResponse response)
	 throws ServletException, IOException {
	 String url = "member/login.jsp";

	 HttpSession session = request.getSession();

	 MemberVO memberVO = new MemberVO();

	 memberVO.setTrapperid(request.getParameter("trapperid"));
	 memberVO.setTrapperpw(request.getParameter("trapperpw"));
	 memberVO.setTrappername(request.getParameter("trappername"));
	 memberVO.setTrappernickname(request.getParameter("trappernickname"));
	 memberVO.setTrapperphone(request.getParameter("trapperphone"));
	
	 MemberDAO memberDAO = MemberDAO.getInstance();
	 memberDAO.insertMember(memberVO);

	 RequestDispatcher dispatcher = request.getRequestDispatcher(url);
	 dispatcher.forward(request, response);
	 }
	}