package MEMBER;

import java.sql.Timestamp;

public class MemberVO {

	private int trapperaccount;
	 private String trapperid;
	 private String trappername;
	 private String trapperpw;
	 private String trappernickname;
	 private String trapperphone;
	 private Timestamp indate;
	 private int score;
	 private int howmanytraps;
	 
		 public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getHowmanytraps() {
		return howmanytraps;
	}
	public void setHowmanytraps(int howmanytraps) {
		this.howmanytraps = howmanytraps;
	}
		public int getTrapperaccount() {
		return trapperaccount;
	}
	public void setTrapperaccount(int trapperaccount) {
		this.trapperaccount = trapperaccount;
	}
	public String getTrapperid() {
		return trapperid;
	}
	public void setTrapperid(String trapperid) {
		this.trapperid = trapperid;
	}
	public String getTrappername() {
		return trappername;
	}
	public void setTrappername(String trappername) {
		this.trappername = trappername;
	}
	public String getTrapperpw() {
		return trapperpw;
	}
	public void setTrapperpw(String trapperpw) {
		this.trapperpw = trapperpw;
	}
	public String getTrappernickname() {
		return trappernickname;
	}
	public void setTrappernickname(String trappernickname) {
		this.trappernickname = trappernickname;
	}
	public String getTrapperphone() {
		return trapperphone;
	}
	public void setTrapperphone(String trapperphone) {
		this.trapperphone = trapperphone;
	}
		public Timestamp getIndate() {
		 return indate;
		 }
		 public void setIndate(Timestamp indate) {
		 this.indate = indate;
		 }
}
