package MEMBER;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UTIL.Action;

public class LoginActoin  implements Action {
	 @Override
	 public void execute(HttpServletRequest request, HttpServletResponse response)
	 throws ServletException, IOException {
	 String url="member/login_fail.jsp";
	 HttpSession session=request.getSession();

	 String id=request.getParameter("trapperid");
	 String pwd=request.getParameter("trapperpw");

	 MemberDAO memberDAO=MemberDAO.getInstance();
	 int mvo=memberDAO.Login(id, pwd);
	

	 request.getRequestDispatcher(url).forward(request, response);
	 }
	}