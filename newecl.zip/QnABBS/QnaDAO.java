package QnABBS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import MEMBER.MemberVO;
import UTIL.ConnectDB;

public class QnaDAO {
	
	Connection conn = null;
	PreparedStatement pre = null;
	ResultSet rs = null;
	
	private QnaDAO() {
	}

	private static QnaDAO instance = new QnaDAO();

	public static QnaDAO getInstance() {
		return instance;
	}

	public ArrayList<QnaVO> listQna(String id) {
		ArrayList<QnaVO> qnaList = new ArrayList<QnaVO>();
		String sql = "select * from totqnabbs order by qnanum asc";

		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);
			pre.setString(1, id);
			rs = pre.executeQuery();
			while (rs.next()) {
				QnaVO qnaVO = new QnaVO();
				qnaVO.setTrapperaccount(rs.getInt("trapperaccount"));
				qnaVO.setTrappernickname(rs.getString("trappernickname"));
				qnaVO.setTitle(rs.getString("title"));
				qnaVO.setContent(rs.getString("content"));
				qnaVO.setReply(rs.getString("reply"));
				qnaVO.setIndate(rs.getTimestamp("bbsdate "));
				qnaList.add(qnaVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return qnaList;
	}

	public QnaVO getQna(int qnanumber) {
		QnaVO qnaVO = null;
		String sql = "select * from totqnabbs where qnanum=?";
		
		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);
			pre.setInt(1, qnanumber);
			rs = pre.executeQuery();
			if (rs.next()) {
				qnaVO = new QnaVO();
				qnaVO.setQnanum(rs.getInt("qnanum"));
				qnaVO.setTrapperaccount(rs.getInt("trapperaccount"));
				qnaVO.setTrappernickname(rs.getString("trappernickname"));
				qnaVO.setTitle(rs.getString("title"));
				qnaVO.setContent(rs.getString("content"));
				qnaVO.setReply(rs.getString("reply"));
				qnaVO.setIndate(rs.getTimestamp("bbsdate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre);
		}
		return qnaVO;
	}
	
public String findnick(String trapperaccount) {
		
		MemberVO mvo = new MemberVO();
		String sql="select trappernickname from totmember where trapperaccount=?";
		
		String trappernickname=null;
		try {
			
			conn =ConnectDB.getConnection();
			conn.setAutoCommit(false);
			conn.commit();
			pre = conn.prepareStatement(sql);
			pre.setInt(1, Integer.parseInt(trapperaccount));
			
			rs = pre.executeQuery();
			if (rs.next()) {
				mvo.setTrappernickname(rs.getString("trappernickname"));
			}
			conn.commit();
			
			System.out.println("find nick ok");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectDB.close(conn, pre, rs);
		}
		trappernickname=mvo.getTrappernickname();
		System.out.println("usernick : "+trappernickname);
		return trappernickname;
	}	

	public String insertqna(QnaVO qvo) {
		
		String okornot="notok";
		String sql = "insert into totqnabbs (title, " + 
	"content, trapperaccount, trappernickname, "
	+ "bbsdate) values(?, ?, ?, ?, now())";
		
		try {
			conn = ConnectDB.getConnection();
			pre = conn.prepareStatement(sql);
			pre.setString(1, qvo.getTitle());
			pre.setString(2, qvo.getContent());
			pre.setInt(3, qvo.getTrapperaccount());
			pre.setString(4, qvo.getTrappernickname());
			pre.executeUpdate();
			System.out.println(qvo.getTitle());
			okornot="ok";
		} catch (Exception e) {
			e.printStackTrace();
			okornot="notok";
		} finally {
			ConnectDB.close(conn, pre);
		}
		return okornot;
	}
	public ArrayList<QnaVO> listAllQna() {
		 ArrayList<QnaVO> qnaList = new ArrayList<QnaVO>();

		 String sql = "select * from totqnabbs order by bbsdate desc";
		 
		 try {
		 conn = ConnectDB.getConnection();
		 pre = conn.prepareStatement(sql);
		 rs = pre.executeQuery();
		 while (rs.next()) {
		 QnaVO qnaVO = new QnaVO();
		 qnaVO.setQnanum(rs.getInt("qnanum"));		
		qnaVO.setTrappernickname(rs.getString("trappernickname"));
		qnaVO.setTitle(rs.getString("title"));
		qnaVO.setContent(rs.getString("content"));
		qnaVO.setReply(rs.getString("reply"));
		qnaVO.setIndate(rs.getTimestamp("bbsdate"));
		 qnaList.add(qnaVO);
		 System.out.println("title : " +rs.getString("title") );
		 }
		 } catch (Exception e) {
		 e.printStackTrace();
		 }
		 return qnaList;
		 }
		 public void updateQna(QnaVO qnaVO) {
		 String sql = "update totqnabbs set reply=?, rep='2' where qnanum=?";
		 
		 try {
			 conn = ConnectDB.getConnection();
			 pre = conn.prepareStatement(sql);
			 pre.setString(1, qnaVO.getReply());
			 pre.setInt(2, qnaVO.getQnanum());
			 pre.executeUpdate();
			 } catch (Exception e) {
			 e.printStackTrace();
			 } finally {
				 ConnectDB.close(conn, pre);
			 }
		 }
		 
		 public String fixQna(QnaVO qnaVO) {
			 String sql = "update totqnabbs set title=?, content=? where qnanum=? and trapperaccount=?";
			 String okornot="notok";
			 try {
				 conn = ConnectDB.getConnection();
				 pre = conn.prepareStatement(sql);
				 System.out.println("start "+qnaVO.getTitle());
				 pre.setString(1, qnaVO.getTitle());
				 pre.setString(2, qnaVO.getContent());
				 pre.setInt(3, qnaVO.getQnanum());
				 pre.setInt(4, qnaVO.getTrapperaccount());
				 pre.executeUpdate();
				 okornot="ok";
				 } catch (Exception e) {
				 e.printStackTrace();
				 okornot="notok";
				 } finally {
					 ConnectDB.close(conn, pre);
				 }
			 return okornot;
			 }
	
		 public String deleteQna(int qnanumber) {
			 String sql = "delete from totqnabbs where qnanum=?";
			 String okornot="notok";
			 try {
				 conn = ConnectDB.getConnection();
				 pre = conn.prepareStatement(sql);
				 pre.setInt(1, qnanumber);
				 pre.executeUpdate();
				 System.out.println("delete compl");
				 okornot="ok";
				 } catch (Exception e) {
				 e.printStackTrace();
				 okornot="notok";
				 } finally {
					 ConnectDB.close(conn, pre);
				 }
			 return okornot;
		 }
}