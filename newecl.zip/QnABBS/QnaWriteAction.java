package QnABBS;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import MEMBER.MemberVO;
import UTIL.Action;

public class QnaWriteAction implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "TOTServer?command=qna_list";

		 
		int trapperaccount=Integer.parseInt(request.getParameter("trapperaccount"));
		
			 QnaVO qnaVO = new QnaVO();
			 qnaVO.setTitle(request.getParameter("title"));
			 qnaVO.setContent(request.getParameter("content"));
			 QnaDAO qnaDAO = QnaDAO.getInstance();
			 qnaDAO.insertqna(qnaVO); 
		 
		 request.getRequestDispatcher(url).forward(request, response);
		 }
	
}